#!/usr/bin/env bash
#!/bin/bash

--pve:vm() {
    --sys:apt:install qemu-guest-agent
}
