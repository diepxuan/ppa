mod debian/pdo_sqlsrv.ini
